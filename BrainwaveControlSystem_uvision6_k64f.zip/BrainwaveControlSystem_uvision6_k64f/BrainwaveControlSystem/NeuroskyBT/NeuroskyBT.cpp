#include "NeuroskyBT.h"

void NeuroskyBT::init(){
    timer.start();
    blinkTimer.start();
    // system variables
    lastReceivedPacket = 0;
    bigPacket = false;
    brainwave = false;
    wavePacket = false;
    for (int i = 0; i < 64; i++){
        payloadData[i] = 0;
    }
    //Checksum variables
    generatedChecksum = 0;
    checksum = 0; 
    payloadLength = 0;
    //payloadData[64] = {};
    poorQuality = 0;
    quality = 0;
    tSinceLastPacket = 0;
    tblink = 0;
    printed = false;
    //Mindwave variables
    attention = 0;
    meditation = 0;
    for (int i = 0; i < 7; i++){
        ASIC_EEG[i] = 0;
    }
    time = 0;
    RAW_wave = 0;
    readblink = false;
}

void NeuroskyBT::read_stream(bool print){
  // Byte order: 0xAA , 0xAA, PayloadLength, PayloadData, Checksum
  // Look for sync bytes
  printed = false;
  if(ReadOneByte() == 0xAA) { // 170 = 0b10101010 = 0xAA
  if(ReadOneByte() == 0xAA) { // 170 = 0b10101010 = 0xAA
        
     payloadLength = ReadOneByte();
     if (payloadLength > 169) return;              //Payload length can not be greater than 169
     
     generatedChecksum = 0;        
     for(int i = 0; i < payloadLength; i++) {  
       payloadData[i] = ReadOneByte();            //Read payload into memory
       generatedChecksum += payloadData[i];       //Calculate generated checksum
     }  
     
     checksum = ReadOneByte();                      //Read checksum byte from stream 
     generatedChecksum = 255 - generatedChecksum;   //Take one's compliment of generated checksum
     
     if(checksum == generatedChecksum) {        //If correct checksum   
       read_payload();
       if (bigPacket) {
            tSinceLastPacket = timer.read_ms();
            if (print) send_to_pc();
            quality = 100*(255 - poorQuality)/255;
            printed = true;
            bigPacket = false;
            timer.reset();
       }
      }
    } // end if read 0xAA
    } // end if read 0xAA
    tSinceLastPacket = timer.read_ms();
}

unsigned char NeuroskyBT::ReadOneByte(){
    int ByteRead;
    
    while(!(headset.readable())){}
    ByteRead = headset.getc();
    
    return ByteRead;
}

int NeuroskyBT::read_3byte_int(int i){
    return ((payloadData[i] << 16) + (payloadData[i+1] << 8) + payloadData[i+2]);
}

void NeuroskyBT::read_waves(int i){
  int n = i+21;
  int w = 0;
   while (i <= n) {
      ASIC_EEG[w] = read_3byte_int(i);
      w++;
      i+=3;
    }
}

void NeuroskyBT::read_payload(){
    poorQuality = 100;
    attention = 0;
    meditation = 0;
       
    for(int i = 0; i < payloadLength; i++) {    // Parse the payload
        switch(payloadData[i]){
            //Check if any of the following CODE bytes is detected
            case 0x02: // poorQuality CODE
            i++;
            poorQuality = payloadData[i];
            bigPacket = true;
            break;
            
            case 0x04: // Attention CODE
            i++;
            attention = payloadData[i];
            bigPacket = true;
            break;
            
            case 0x05: // Meditation CODE
            i++;
            meditation = payloadData[i];
            bigPacket = true;
            break;
            
            case 0x80: //RAW Wave Value: 16-bit two's compelment signed value
            RAW_wave = (payloadData[i+2]<<8) + payloadData[i+3]; //Skip the code and Ex code
            if (RAW_wave > 32767) RAW_wave -= 65536; //If MSB is 1, take two's complement
            //Sample per 50ms
            if ((blinkTimer.read_ms() - time) > 50) { 
                if (RAW_wave<-200 && !blinked) {
                time = blinkTimer.read_ms();
                blinked = true; 
                readblink = false;
                } else {
                //reset_blink();
                //time = blinkTimer.read_ms();
                }
            }
            //Wait for blink to settle ~ approximately 150ms to 300ms
            if (blinkTimer.read_ms() > 200) {
                reset_blink();
            }
            i = i + 3;
            wavePacket = true;
            break;
            case 0x83: // ASIC EEG POWER
            read_waves(i+2); //Skip the CODE and the V.LENGTH Bytes then read EEG Signals
            i = i + 25; //read_wave() reads 8 EEG signals, each 3 bytes, hence skip them
            break;
        }
    } // for loop
} //read_payload

bool NeuroskyBT::get_bigpacket(){
    return bigPacket;
}


void NeuroskyBT::send_to_pc(){
    //Time since last packet ,Poor Qualtiy, Attention, Mediation, 
    //Delta, Theta, Low Alpha, High Alpha, Low Beta, High Beta, Low Gamma, Mid Gamma, RAW EEG
    pc.printf("\n%d,%u,%u,%u",tSinceLastPacket,poorQuality, attention, meditation);    
    for (int i = 0; i < 7; i++) printf(",%u",ASIC_EEG[i]);                                   
}

int NeuroskyBT::get_tSinceLastPacket(){
    return tSinceLastPacket;
}

int NeuroskyBT::get_quality(){
    return quality;
}

int NeuroskyBT::get_attention(){
    return attention;
}
    
int NeuroskyBT::get_meditation(){
    return meditation;
}

unsigned int NeuroskyBT::get_delta_wave(){
    return ASIC_EEG[0];
}

unsigned int NeuroskyBT::get_theta_wave(){
    return ASIC_EEG[1];
}

unsigned int NeuroskyBT::get_low_alpha_wave(){
    return ASIC_EEG[2];
}

unsigned int NeuroskyBT::get_high_alpha_wave(){
    return ASIC_EEG[3];
}

unsigned int NeuroskyBT::get_low_beta_wave(){
    return ASIC_EEG[4];
}

unsigned int NeuroskyBT::get_high_beta_wave(){
    return ASIC_EEG[5];
}

unsigned int NeuroskyBT::get_low_gamma_wave(){
    return ASIC_EEG[6];
}
unsigned int NeuroskyBT::get_mid_gamma_wave(){
    return ASIC_EEG[7];
}

bool NeuroskyBT::check_blink(){
    readblink = true;
    return blinked;
}

bool NeuroskyBT::check_blinkgate(){
    return readblink;
}


bool NeuroskyBT::print_check(){
    return printed;
}

void NeuroskyBT::reset_blink(){
    blinked = false;
    blinkTimer.reset(); 
    time = 0;
}

void NeuroskyBT::test(){
    pc.printf("Test");
}
