/*
* This library that was built for the FRDM K64F microcontroller to decode data 
* sent by the ThinkGearTM chip was influenced by the Arduino code developed by 
* S. Kravitz at (S. Kravitz, "Hackers in Residence - Hacking MindWave Mobile - 
* learn.sparkfun.com", Learn.sparkfun.com, 2013. [Online]. Available: 
* https://learn.sparkfun.com/tutorials/hackers-in-residence---hacking-mindwave-mobile/all. 
* [Accessed: 10- Jan- 2020]. The code was adjusted to adapt with the FRDM K64F 
* microcontroller and to collect the RAW wave at higher sampling rate, which was 
* found useful in predicting the eyeblinks.
*
*
*/

#ifndef NEUROSKYBT_H
#define NEUROSKYBT_H

#define BAUDRATE 57600
#define DEBUGOUTPUT 0
#define powercontrol 10

#include "mbed.h"
#include "FXOS8700Q.h"
    
class NeuroskyBT {
    
    public:
    // USB Port and Bluetooth UART pins inititalisation
    NeuroskyBT() : pc(USBTX,USBRX,BAUDRATE), headset(PTC17,PTC16, BAUDRATE), timer() {}
    void init();
    void read_stream(bool print);
    void send_to_pc();
    
    int get_quality();
    int get_attention();
    int get_meditation();
    int get_tSinceLastPacket();

    unsigned int get_delta_wave();
    unsigned int get_theta_wave();
    unsigned int get_low_alpha_wave();
    unsigned int get_high_alpha_wave();
    unsigned int get_low_beta_wave();
    unsigned int get_high_beta_wave();
    unsigned int get_low_gamma_wave();
    unsigned int get_mid_gamma_wave();    
    
    bool check_blink();
    bool print_check();
    bool check_blinkgate();
    void reset_blink();
    void test();
    
    private:
    Serial pc;
    Serial headset;
    Timer timer;
    Timer blinkTimer;
    int time;
    // System functons
    unsigned char ReadOneByte();
    int read_3byte_int(int i);
    void read_waves(int i);
    void read_payload(); 
    bool get_bigpacket();
    // System variables
    long lastReceivedPacket;
    bool bigPacket;
    bool wavePacket;
    bool brainwave;
    bool blinked;
    // Checksum variables
    int payloadLength;
    char generatedChecksum;
    char checksum; 
    char payloadData[64];
    //System variables
    int tSinceLastPacket;
    int tblink;
    char poorQuality;
    char quality;
    bool printed;
    //Mindwave variables
    unsigned int ASIC_EEG[8];
    int RAW_wave;
    char attention;
    char meditation;
    bool readblink; 
};
#endif
