#include "Motor.h"

Motor::Motor(
          PinName const enPin,
          PinName const in1Pin,
          PinName const in2Pin)
    :
    _en(new PwmOut(enPin)),
    _in1(new DigitalOut(in1Pin)),
    _in2(new DigitalOut(in2Pin))
{}


Motor::~Motor(){
    delete _en;
    delete _in1;
    delete _in2;
}

void Motor::init(){
    setPwm(1/500, 0.5); //Set PWM frequency to 500, and 50% duty ratio
}

void Motor::forward(){
    _in1->write(1);
    _in2->write(0);
}

void Motor::backward(){
    _in1->write(0);
    _in2->write(1);
}

void Motor::stop(){
    _in1->write(0);
    _in2->write(0);
}


void Motor::setPwm(float period, float dutyratio){
    _en->period(period);
    _en->write(dutyratio);
}
