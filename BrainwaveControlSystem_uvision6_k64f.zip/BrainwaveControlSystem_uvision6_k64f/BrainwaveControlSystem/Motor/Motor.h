#ifndef MOTOR_H
#define MOTOR_H

#include "mbed.h"

class Motor {
    private:
    // objects
    PwmOut      *_en;
    DigitalOut  *_in1;
    DigitalOut  *_in2;
    
    public:
    Motor(PinName const enPin,
          PinName const in1Pin,
          PinName const in2Pin);
    ~Motor();
    
    void init();
    void forward();
    void backward();
    void stop();
    void setPwm(float period,float dutyratio);
};


#endif