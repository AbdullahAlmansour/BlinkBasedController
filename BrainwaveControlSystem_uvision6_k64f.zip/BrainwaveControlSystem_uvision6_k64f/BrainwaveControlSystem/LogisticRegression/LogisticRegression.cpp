#include "LogisitcRegression.h"

double LogisticRegression::mean(int *array) {
  int i, sum = 0;   
  double mean;          

   while(*array != '\0') {
      sum += *array; // Add element
      array++; //Increment pointer
      i += 1; //Count elements
   }
   mean = double(sum)/i;
   return mean;
}


double LogisticRegression::stdev(int *array, double mean, int n){
    double sum, dif = 0.0;
    int i = 0;
    for (i = 0; i < n; i++){
       dif = (*array) -  mean;
       sum += pow(dif,2); //Difference to the mean, sqaured
    }
    return sqrt(sum/(n-1));
}

double LogisticRegression::zscore(double std, double mean, double x){
    return (x - mean)/std;
}

double LogisticRegression::sigmoid(double theta[], unsigned int x[]){
    int i = 0;
    double z = 0.0;
    z = z + theta[i];
    while (theta[i] != '\0'){
        i++;
        z = z + theta[i]*x[i-1];
    }
    return 1./(1+exp(-1*z));
}

bool LogisticRegression::predict(double theta[], unsigned int x[]){
    double g = sigmoid(theta, x);
    if (g >= 0.5) return 1;
    else return 0; 
}
