#ifndef LOGISTIC_REGRESSION
#define LOGISITC_REGRESSION

#include "mbed.h"
#include <math.h>

class LogisticRegression {
    public:
    double mean(int *array);
    double stdev(int *array, double mean, int n);
    double zscore(double std, double mean, double x);
    double sigmoid(double theta[], unsigned int x[]);
    bool predict(double theta[], unsigned int x[]);
    
    private:
};

#endif