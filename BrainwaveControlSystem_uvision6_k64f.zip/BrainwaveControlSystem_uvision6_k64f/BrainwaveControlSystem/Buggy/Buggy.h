#ifndef BUGGY_H
#define BUGGY_H

#include "mbed.h"
#include "Motor.h"

class Buggy {
    public:
    Buggy() : R1(PTC10, PTA2, PTB23), R2(PTC2, PTC0, PTC9),
              L1(PTC4, PTB20, PTC8),  L2(PTC3, PTC5, PTC7) {}
    
    void init();
    void forward();
    void backward();
    void clockwise();
    void anticlockwise();
    void stop();
    void setSpeed(float period, float dutyratio);
    void slowSpeed();
    void highSpeed();
    
    private:
    Motor R1;
    Motor R2;
    Motor L1;
    Motor L2;
};

#endif