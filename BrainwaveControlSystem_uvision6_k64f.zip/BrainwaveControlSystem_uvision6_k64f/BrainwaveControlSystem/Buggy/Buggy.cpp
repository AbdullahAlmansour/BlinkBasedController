#include "Buggy.h"

void Buggy::init(){
    R1.init();
    R2.init();
    L1.init();
    L2.init();
}

void Buggy::forward(){
    R1.forward();
    R2.forward();
    L1.forward();
    L2.forward();
}

void Buggy::backward(){
    R1.backward();
    R2.backward();
    L1.backward();
    L2.backward();
}

void Buggy::clockwise(){
    R1.backward();
    R2.backward();
    L1.forward();
    L2.forward();
}

void Buggy::anticlockwise(){
    R1.forward();
    R2.forward();
    L1.backward();
    L2.backward();
}

void Buggy::stop(){
    R1.stop();
    R2.stop();
    L1.stop();
    L2.stop();
}

void Buggy::setSpeed(float period, float dutyratio){
    R1.setPwm(period, dutyratio);
    R2.setPwm(period, dutyratio);
    L1.setPwm(period, dutyratio);
    L2.setPwm(period, dutyratio);
}

void Buggy::slowSpeed(){
    R1.setPwm(1/500, 0.1);
    R2.setPwm(1/500, 0.1);
    L1.setPwm(1/500, 0.1);
    L2.setPwm(1/500, 0.1);
}

void Buggy::highSpeed(){
    R1.setPwm(1/500, 0.5);
    R2.setPwm(1/500, 0.5);
    L1.setPwm(1/500, 0.5);
    L2.setPwm(1/500, 0.5);
    
}