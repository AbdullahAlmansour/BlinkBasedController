/*
* Abdullah Almansour
* University of Leeds
* ID: 201184632
* Final year project: Brainwave-control system for Electric Chair and/or Artificial Arms
* Discription: This project attempts to use the Electroencephalogram (EEG) signal from the 
* brain to provide a new communication channel that allows palaysed individuals navigate freely
* by controlling their electric chairs. The project uses a low-end EEG-acquisition headset, 
* which is the Neurosky Mindwave Mobile headset, to collect the EEG signals via a single electrode
* placed on the forehead, and an FRDM-K64F microcontroller to process the acquired signals 
* and initiate the navigation commands that control an electric buggy, which simulate the 
* electric chair movement. The project exploits the use of eyeblinks and the ERD/ERS signal 
* to control the electric buggy by processing the acquired signal by the EEG headset. As an 
* eyeblink causes a peak in the acquired EEG signal, the FRDM-K64 microcontroller detects this 
* peak and uses it as the main control signal in the navigation process. The eyeblinks are used 
* to initiate the navigation and to choose the direction of movement, while the Event-Related 
* Desynchronization/Event-Related Synchronization (ERD/ERS) signal, which measures the attention 
* level of the user, is used to move the buggy in the chosen direction. 
*/

#include "mbed.h"
#include "FXOS8700Q.h"
#include "NeuroskyBT.h"
#include "N5110.h"
#include "Buggy.h"
#include "LogisitcRegression.h"
#include "Motor.h"
#include <cmath>


// Global Objects
NeuroskyBT neurosky;
N5110 lcd(PTE24,PTE25,PTD3,PTD2,PTD1,PTD0);
Buggy buggy;
Timer timer;

// Leds : 1 = OFF || 0 = ON
DigitalOut led1(PTA1);
DigitalOut led2(PTB9);
DigitalOut led3(PTC1);
DigitalOut led4(PTC11);
DigitalOut blinkled(PTE26);

// Buttons are Pulled Up : Not pressed = High || Pressed = Low
DigitalIn button1(PTB19);
DigitalIn switch1(PTB18);//


// Global Functions
void init();
void init_leds();
void show_indicators();
void print_on_pc();
void print_on_lcd();
void navigate();
void flash_led();
void blinked();
void stop_and_reset();

void command();
void navigate();
void count_blinks(int miliseconds);
void resetblinks();
bool read_one_blink();
void read_two_blinks();
void show_navigation_direction();

// Global Variables
float t1 = 0.0f;
float t2 = 0.0f;
bool firstblink = 0;
bool secondblink = 0;
bool direction_determined = 0;
bool count_gate = 0;
bool blinks_counted = 0;
int blinks = 0;



int main(void)
{
    init();
    lcd.setContrast(0.4);
    while(1){
        if (switch1.read()){
          while(!button1){
           neurosky.read_stream(0);
           show_indicators();
           command();
         }
        } else {
           //testing();
          print_on_pc();
        }// if chain
    }// while
}// main

void command(){
     read_two_blinks();
     if (secondblink) { // If two blinks were detected
         if (!blinks_counted) { // Blinks not yet counted
             blinkled = 0;
             count_blinks(5000); // Read Blinks
         } else { // Finish counted
            blinkled = 1;
            navigate(); // Start navigating
            if (read_one_blink()) {
                stop_and_reset(); // Exit blink detect
                }
         }
    }
}


void count_blinks(int miliseconds){
    if (timer.read_ms() - t2 < miliseconds){
        blinks += read_one_blink();
    } else {
      blinks_counted = true;
    }
}

void resetblinks() {
    firstblink = 0;
    secondblink = 0;
    blinks = 0;
    blinks_counted = 0;
}



void navigate(){
        int direction = 0;
        if (blinks >= 0 && blinks < 2) {led1 = 1; direction = 1;}
        else if (blinks >= 2  && blinks < 4) {led2 = 1; direction = 2;}
        else if (blinks >= 4 && blinks < 6) {led3 = 1; direction = 3;}
        else if (blinks > 6) {led4 = 1; direction = 4;}
        else stop_and_reset(); // Invalid command
        
        if (neurosky.get_attention() >= 50){
            switch (direction){
            case (1):
                buggy.highSpeed();
                buggy.forward(); break;
            case (2):
                buggy.slowSpeed();
                buggy.anticlockwise(); break;
            case (3):
                buggy.slowSpeed();
                buggy.clockwise(); break;
            case (4):
                buggy.slowSpeed();
                buggy.backward();
            default:
                stop_and_reset();
            }
        }
}


void read_two_blinks(){
     if (!secondblink){ //second blink not yet detected
        if (!firstblink){ //If first blink not yet detected
            firstblink = read_one_blink();
            t1 =  timer.read_ms(); //Record time of first blink
        } else { // Detected first blink
            t2 = timer.read_ms(); //Update current time
            if (((t2 - t1) < 1000)) { // Detect second blink within 2 seconds
             secondblink = read_one_blink(); //If detected another blink, start navigating
             blinks = 0; //Reset blink counter;
            } else //2 secs has passed passed without a second blink 
             stop_and_reset(); // Ignore and Reset
        }
     }    
}

bool read_one_blink(){
    bool blink = 0;
    if (neurosky.get_quality() == 100){ // Check that the signal has good quality
     if (!neurosky.check_blinkgate()){ // Check that enough time has past since last blink
      if (neurosky.check_blink()) {
          blink = 1; // Read blink
          flash_led();
          }
     }
    }
    return blink;
}



void init(){
    neurosky.init();
    lcd.init();
    init_leds();
    timer.start();
    buggy.init();
    
    lcd.clear();
    lcd.printString("Blink Project",0,0);
    lcd.printString("Author:",0,2);
    lcd.printString("Abdullah",0,3);
    lcd.printString("Almansour",0,4);
    lcd.refresh();
    
    
}

void init_leds(){
    led1 = 0;
    led2 = 0;
    led3 = 0;
    led4 = 0;
    blinkled = 1;
}



void show_indicators(){
    print_on_lcd();
}

void stop_and_reset(){
    printf("\nBlink Count = %i", blinks);
    buggy.stop();
    init_leds();
    resetblinks();
}

void print_on_pc(){
    int i = 0;
    
    if (button1) {// For Learning purposes
        led1 = 1;
        while(i < 3){
          neurosky.read_stream(1);
          if (neurosky.print_check()) {printf(",1"); i++;} 
        }   
    } else { //No test
          neurosky.read_stream(0);
          //if (neurosky.print_check()) printf(",0"); 
    }
}

void print_on_lcd(){
    if (neurosky.print_check()){
        int attention = neurosky.get_attention();
        int meditation = neurosky.get_meditation();
        int quality = neurosky.get_quality();
        //if (neurosky.get_tSinceLastPacket() > 1100) led1 = 1; else led1 = 0;
        
        lcd.clear();
        lcd.printString("Att",0,0);
        lcd.drawRect(19,0,50,8,FILL_TRANSPARENT);
        lcd.drawRect(19,0,attention*50/100,8,FILL_BLACK);
        lcd.printString("Med",0,1);
        lcd.drawRect(19,9,50,8,FILL_TRANSPARENT);
        lcd.drawRect(19,9,meditation*50/100,8,FILL_BLACK);
        lcd.printString("Qlt",0,5);
        lcd.drawRect(19,40,50,8,FILL_TRANSPARENT);
        lcd.drawRect(19,40,quality*50/100,8,FILL_BLACK);
        lcd.refresh();
        wait_ms(1);
    }
}

void flash_led(){
    blinkled = 0;
    wait_ms(20);
    blinkled = 1;
}



void blinked(){
    //flash_led();
    printf("\nBlinked\n");
}

///////////////////////////////////////////////////////////////////////////////
/////Functions below this line have been removed from the control process./////
/////They were initially used to test and experiment with the system.     /////
///////////////////////////////////////////////////////////////////////////////
bool log_reg(float u, float sdev,
             float theta0, float theta1, unsigned int val);
bool log_pred();
bool thres_pred();
bool blink_predict();
void testing();

void testing(){
     neurosky.read_stream(1);
     if (neurosky.print_check()){
        show_indicators();
        if (blink_predict()) {blinked();}
        //neurosky.reset_blink();
     } 
}

bool blink_predict(){
    bool blk = 0;
    //blk = log_pred();
    blk = thres_pred();
    return blk;
}
    
bool log_pred(){
    unsigned int Delta       =   neurosky.get_delta_wave();
    unsigned int Theta       =   neurosky.get_theta_wave();
    unsigned int LowAlpha    =   neurosky.get_low_alpha_wave();
    unsigned int HighAlpha   =   neurosky.get_high_alpha_wave();
    unsigned int LowBeta     =   neurosky.get_low_beta_wave();
    unsigned int HighBeta    =   neurosky.get_high_beta_wave();
    unsigned int LowGamma    =   neurosky.get_low_gamma_wave();
    unsigned int MidGamma    =   neurosky.get_mid_gamma_wave();
    //printf("\n-%u,%u,%u,%u|%u,%u",
    //        Delta,Theta,LowAlpha,HighAlpha,LowGamma,MidGamma);
    
    bool deltaB = log_reg(370724,551189.8,-6.9885,6.3276, Delta);
    bool thetaB = log_reg(154191.6,250840.6,-6.0713,6.1849, Theta);
    bool lowalphaB = log_reg(36920.15,62064.3,-6.8942,4.9022, LowAlpha);
    bool highalphaB = log_reg(23237.38,40541.88,-6.589,5.0858, HighAlpha);
    bool lowgammaB = log_reg(8641.56,15758.4,-5.9445,6.2514, LowGamma);
    bool midgammaB = log_reg(5786.118,10474.83,-7.3130, 2.2298, MidGamma);
    
    if (deltaB | thetaB){ //highalphaB //midgammaB //lowgammaB //highalphaB
     printf("\nBLINKED");
     return 1;
    } else return 0;
}

bool log_reg(float u, float sdev,
             float theta0, float theta1, unsigned int val)
{   
    double z = (val - u)/sdev;
    z = theta0 + theta1*z;
    z = 1./(1+exp(-1*z));
    //printf("\npred = %lf",z);
    if (z >= 0.5) return 1;
    else return 0;
}



bool thres_pred(){
    unsigned int Delta       =   neurosky.get_delta_wave();
    unsigned int Theta       =   neurosky.get_theta_wave();
    unsigned int LowAlpha    =   neurosky.get_low_alpha_wave();
    unsigned int HighAlpha   =   neurosky.get_high_alpha_wave();
    unsigned int LowBeta     =   neurosky.get_low_beta_wave();
    unsigned int HighBeta    =   neurosky.get_high_beta_wave();
    unsigned int LowGamma    =   neurosky.get_low_gamma_wave();
    unsigned int MidGamma    =   neurosky.get_mid_gamma_wave();
    
    int count = 0;
    
    if (neurosky.get_quality() == 100){
        if (Delta >= 1030000) {count++;}
        if (Theta >= 424000) {count++;}
       //if (LowAlpha >= 130000) {count++;}
       //if (HighAlpha >= 78770) {count++;}
       //if (LowGamma >= 25000) {count++;}
       //if (MidGamma >= 40480) {count++;}
    }

    if (count >= 1)
          return 1; 
    else return 0;
}